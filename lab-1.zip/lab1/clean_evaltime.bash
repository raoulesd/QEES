#!/bin/bash

cd ./evaluation/publish_time/
rm -f *.txt
cd  ../subscribe_time/
rm -f *.txt
cd  ../transport_time/
rm -f *.txt
cd  ../convert_msg/
rm -f *.txt
cd  ../dds_time/
rm -f *.txt

